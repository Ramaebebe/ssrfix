﻿/* src/app/login/page.tsx */
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase/client";
import { isDemo, demoUser } from "@/lib/config";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState<string>("");

  if (isDemo()) {
    return (
      <main className="min-h-[70vh] flex items-center justify-center p-6">
        <div className="card p-6 max-w-md w-full space-y-4 text-center">
          <h1 className="text-2xl font-semibold">Demo sign-in</h1>
          <p className="text-white/70">
            Demo mode is enabled â€” this skips Supabase authentication.
          </p>
          <button
            className="btn w-full"
            onClick={() => {
              localStorage.setItem("afriportal:demo_mode", "true");
              localStorage.setItem("afriportal:demo_user", JSON.stringify(demoUser));
              router.replace("/client/dashboard");
            }}
          >
            Continue to dashboard
          </button>
          <div className="text-xs text-white/50">
            Turn off demo via <code>NEXT_PUBLIC_DEMO_MODE=false</code> and <code>DEMO_MODE=false</code>.
          </div>
        </div>
      </main>
    );
  }

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setStatus("sending");
    setMessage("");

    try {
      const redirectTo =
        typeof window !== "undefined"
          ? `${window.location.origin}/auth/callback`
          : "/auth/callback";

      const { error } = await supabase.auth.signInWithOtp({
        email,
        options: { emailRedirectTo: redirectTo },
      });

      if (error) {
        setStatus("error");
        setMessage(error.message || "Failed to send magic link.");
        return;
      }

      setStatus("sent");
      setMessage("Magic link sent. Please check your inbox.");
    } catch (err) {
      setStatus("error");
      setMessage(err instanceof Error ? err.message : "Unexpected error.");
    }
  };

  return (
    <main className="min-h-[70vh] flex items-center justify-center p-6">
      <div className="card p-6 max-w-md w-full">
        <h1 className="text-2xl font-semibold mb-1">Sign in</h1>
        <p className="text-white/70 mb-6">
          Enter your email and weâ€™ll email you a magic link.
        </p>

        <form onSubmit={onSubmit} className="space-y-4">
          <label className="block">
            <span className="text-sm text-white/70">Email</span>
            <input
              type="email"
              required
              className="input mt-1 w-full"
              placeholder="you@company.co.za"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>

          <button
            type="submit"
            className="btn w-full"
            disabled={status === "sending"}
          >
            {status === "sending" ? "Sendingâ€¦" : "Send magic link"}
          </button>
        </form>

        {status !== "idle" && (
          <div
            className={
              "mt-4 text-sm " +
              (status === "error" ? "text-red-400" : "text-white/80")
            }
          >
            {message}
          </div>
        )}

        <div className="mt-6 text-xs text-white/50">
          By signing in, you agree to our acceptable use policy.
        </div>
      </div>
    </main>
  );
}
