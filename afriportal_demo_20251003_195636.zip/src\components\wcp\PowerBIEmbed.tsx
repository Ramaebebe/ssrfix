// src/components/wcp/PowerBIEmbed.tsx
"use client";

type Props = {
  title: string;
  embedUrl: string; // public embed or your secured embed URL
};

export default function PowerBIEmbed({ title, embedUrl }: Props) {
  return (
    <div className="card p-4 space-y-2">
      <div className="font-semibold">{title}</div>
      <div className="relative pt-[56.25%]">
        <iframe
          title={title}
          src={embedUrl}
          className="absolute top-0 left-0 w-full h-full rounded-xl"
          frameBorder={0}
          allowFullScreen
        />
      </div>
    </div>
  );
}
