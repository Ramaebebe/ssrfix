// (optional) You can place generated types here later.
// Keeping it minimal to avoid type noise on first run.
