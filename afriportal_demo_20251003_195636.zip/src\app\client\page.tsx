export default function ClientIndex() {
  return <div className="card p-6">Welcome. Use the sidebar.</div>;
}
