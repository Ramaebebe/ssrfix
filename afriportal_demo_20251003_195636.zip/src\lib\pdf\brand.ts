export const BRAND = {
  name: "Afrirent",
  colorHex: "#EC6425",
  logoPath: "/brand/afrirent_logo.png"
};
